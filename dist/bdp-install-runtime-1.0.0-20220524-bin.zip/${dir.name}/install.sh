#! /bin/bash
java -jar lib/third-lib/ProjectName-jar-with-dependencies.jar
